pRRophetic
==========

R package. More to come....
