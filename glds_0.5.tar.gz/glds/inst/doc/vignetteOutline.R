### R code from vignette source 'vignetteOutline.Snw'

###################################################
### code chunk number 1: vignetteOutline.Snw:11-13
###################################################
library("glds")
set.seed(12345)


###################################################
### code chunk number 2: vignetteOutline.Snw:18-19
###################################################
data(aucMat) 


###################################################
### code chunk number 3: vignetteOutline.Snw:23-24
###################################################
# fullAucMat <- completeMatrix(aucMat, nPerms=3)


###################################################
### code chunk number 4: vignetteOutline.Snw:28-29
###################################################
mutationSubset <- c("BRAF", "TP53", "NRAS", "PIK3CA", "KRAS", "FGF4", "LASP1", "FNTA", "SSX1", "IL2", "SDHC")


###################################################
### code chunk number 5: vignetteOutline.Snw:33-34
###################################################
assocsOut <- gldsCorrectedAssoc(fullAucMat, lVecs, markerMat[mutationSubset,], numCorDrugsExclude=100, minMuts=5, additionalCovariateMatrix=NULL)


###################################################
### code chunk number 6: vignetteOutline.Snw:39-41
###################################################
theOrd <- names(sort(unlist(assocsOut$pGlds)))
dfOut <- data.frame(pGlds=unlist(assocsOut$pGlds)[theOrd], betaGlds=unlist(assocsOut$betaGlds)[theOrd], pUncorr=unlist(assocsOut$pNaive)[theOrd], betaUncorr=unlist(assocsOut$betaNaive)[theOrd])


###################################################
### code chunk number 7: vignetteOutline.Snw:45-46
###################################################
print(dfOut[1:10,])


###################################################
### code chunk number 8: vignetteOutline.Snw:49-50
###################################################
sessionInfo()


