### R code from vignette source 'vignetteOutline.Snw'

###################################################
### code chunk number 1: vignetteOutline.Snw:11-13
###################################################
library("glds")
set.seed(12345)


###################################################
### code chunk number 2: vignetteOutline.Snw:18-19
###################################################
data(aucMat) 


###################################################
### code chunk number 3: vignetteOutline.Snw:23-24
###################################################
# fullAucMat <- completeMatrix(aucMat, nPerms=3)


###################################################
### code chunk number 4: vignetteOutline.Snw:28-30
###################################################
mutationSubset <- c("BRAF", "TP53", "NRAS", "PIK3CA", "KRAS", "FGF4", 
"LASP1", "FNTA", "SSX1", "IL2", "SDHC")


###################################################
### code chunk number 5: vignetteOutline.Snw:34-36
###################################################
assocsOut <- gldsCorrectedAssoc(fullAucMat, lVecs, markerMat[mutationSubset,], 
numCorDrugsExclude=100, minMuts=5, additionalCovariateMatrix=NULL)


###################################################
### code chunk number 6: vignetteOutline.Snw:42-46
###################################################
theOrd <- names(sort(unlist(assocsOut$pGlds)))
dfOut <- data.frame(pGlds=unlist(assocsOut$pGlds)[theOrd],
betaGlds=unlist(assocsOut$betaGlds)[theOrd], pUncorr=unlist(assocsOut$pNaive)[theOrd],
betaUncorr=unlist(assocsOut$betaNaive)[theOrd])


###################################################
### code chunk number 7: vignetteOutline.Snw:50-51
###################################################
print(dfOut[1:10,])


###################################################
### code chunk number 8: vignetteOutline.Snw:55-57
###################################################
data(the65Genes)
print(the65Genes)


###################################################
### code chunk number 9: vignetteOutline.Snw:60-61
###################################################
sessionInfo()


